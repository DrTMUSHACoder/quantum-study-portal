import"../modulepreload-polyfill-B5Qt9EMX.js";/* empty css               */const f=[{id:0,title:"Welcome to Week 3: Quantum Algorithms",content:`
            <div style="text-align:center; padding:2rem 0;">
                <p style="font-size:1.1rem; color:#cbd5e1">The Power of Quantum Superposition</p>
                <div style="text-align:left; display:inline-block; border-left:2px solid #38bdf8; padding-left:1rem; margin:2rem 0;">
                    <div style="font-weight:600; margin-bottom:0.8rem; color:#f8fafc">You will explore:</div>
                    <ul style="margin:0; padding-left:1rem; color:#cbd5e1; list-style-type:circle; line-height:1.8">
                        <li>Phase Kickback</li>
                        <li>Deutsch Algorithm</li>
                        <li>Bernstein-Vazirani Logic</li>
                        <li>Grover Search Amplitude</li>
                    </ul>
                </div>
                <div style="margin-top:2rem">
                    <button class="btn btn-primary" onclick="nextStep()" style="flex:0; width:180px; padding: 10px 16px; font-size: 0.85rem;">Start Week 3 →</button>
                    <div style="margin-top:1rem; font-size:0.9rem"><a href="../" style="color:#64748b">Exit to Dashboard</a></div>
                </div>
            </div>
        `},{id:1,title:"Task 1: Phase Kickback",reference:"<strong>Key Concept:</strong><br>Phase kickback occurs when a controlled gate is applied to a target qubit in the $|-\rangle$ state. The eigenvalue of the operator on the target is 'kicked back' to the control qubit as a phase shift.",question:"When applying CX to a target in state $|-\rangle$, what happens to the control qubit?",answerValues:["phase","shift","kickback","z gate"],correctAnswer:"Phase Shift",explanation:"Correct! The phase is flipped (effectively a Z gate) on the control qubit.",simulatorCode:[{name:"X",targets:[1]},{name:"H",targets:[1]},{name:"H",targets:[0]},{name:"CX",targets:[0,1]}],num_qubits:2,num_bits:2,diagramExplain:"📖 Control (q0) in $|+\rangle$, Target (q1) in $|-\rangle$. After CX, q0 becomes $|-\rangle$ due to kickback.",quantumLogic:"Phase Kickback Mechanism",packageRef:`qc.x(1)
qc.h(1)
qc.h(0)
qc.cx(0, 1)
# Phase kicks back from Q1 to Q0`},{id:2,title:"Task 2: Deutsch Algorithm Goal",reference:"<strong>Key Concept:</strong><br>Deutsch's algorithm determines if a boolean function $f: {0,1} \rightarrow {0,1}$ is 'constant' (always 0 or 1) or 'balanced' (half 0, half 1) in just ONE query.",question:"How many queries does Deutsch's algorithm need to check if a function is constant or balanced?",answerValues:["1","one","single"],correctAnswer:"1",explanation:"Correct! Algorithms need multiple queries classically, but one query quantumly.",simulatorCode:["H"],diagramExplain:"📖 The first step of Deutsch: placing qubits in superposition to query both inputs simultaneously.",quantumLogic:"Quantum Parallelism",packageRef:`qc.h(0)
# Querying f(0) and f(1) at once`},{id:3,title:"Task 3: Bernstein-Vazirani Hidden String",reference:"<strong>Key Concept:</strong><br>Bernstein-Vazirani finds a hidden bitstring $s$ from an oracle that computes $f(x) = s cdot x pmod 2$. If $s=1$, the oracle acts like a CX gate.",question:"If $s = 1$, the oracle between the input qubit and the target qubit is equivalent to which gate?",answerValues:["CX","CNOT","controlled-x"],correctAnswer:"CX",explanation:"Correct! A CX gate performs an XOR which matches the dot product logic for a single bit.",simulatorCode:[{name:"H",targets:[0]},{name:"X",targets:[1]},{name:"H",targets:[1]},{name:"CX",targets:[0,1]},{name:"H",targets:[0]}],num_qubits:2,num_bits:2,diagramExplain:"📖 A simple Bernstein-Vazirani circuit for $s=1$.",quantumLogic:"Oracle Query & Dot Product",packageRef:`qc.h(range(n))
qc.append(oracle, range(n+1))
qc.h(range(n))`},{id:4,title:"Task 4: Grover's Search Step",reference:"<strong>Key Concept:</strong><br>Grover's algorithm uses 'Amplitude Amplification'. The two main parts are the Oracle (marking the solution) and the Diffusion operator (reflecting about the mean).",question:"What is the process called that increases the probability of the correct answer in Grover's algorithm?",answerValues:["amplification","amplitude","grover","diffusion"],correctAnswer:"Amplitude Amplification",explanation:"Correct! Amplitude amplification is the core of Grover's quadratic speedup.",simulatorCode:["H","Z","H"],diagramExplain:"📖 A simple reflection operator using Z and H gates.",quantumLogic:"Amplitude Amplification",packageRef:`qc.z(0)
qc.h(0)
# Reflecting state amplitudes`},{id:5,title:"Week 3 Conclusion",content:`
            <div style="text-align:center; padding:2rem 0;">
                <h2 style="color:#a855f7">🚀 Algorithms Mastery!</h2>
                <p style="color:#cbd5e1; margin-top:1rem">You've explored the foundations of Deutsch-Jozsa and Grover Search.</p>
                <div style="margin-top:2rem">
                    <a href="../" class="btn btn-primary" style="width:180px; padding: 10px 16px; font-size: 0.85rem;">Return to Home</a>
                </div>
            </div>
        `}];let g=0;const v={simulate(n,o=1){let t=Math.pow(2,o),e=new Array(t).fill(0).map(()=>({re:0,im:0}));e[0].re=1,n.forEach(r=>{const a=(typeof r=="string"?r:r.name).toUpperCase(),d=typeof r=="string"?[0]:r.targets;if(a==="X")d.forEach(s=>{let i=JSON.parse(JSON.stringify(e));for(let c=0;c<t;c++)if(c>>s&1){let l=c^1<<s;i[l]=e[c],i[c]=e[l]}e=i});else if(a==="H")d.forEach(s=>{const i=1/Math.sqrt(2);let c=new Array(t).fill(0).map(()=>({re:0,im:0}));for(let l=0;l<t;l++){let b=l>>s&1,u=l^1<<s;b===0&&(c[l].re+=e[l].re*i+e[u].re*i,c[l].im+=e[l].im*i+e[u].im*i,c[u].re+=e[l].re*i-e[u].re*i,c[u].im+=e[l].im*i-e[u].im*i)}e=c});else if(a==="Z")d.forEach(s=>{for(let i=0;i<t;i++)i>>s&1&&(e[i].re*=-1,e[i].im*=-1)});else if(a==="CX"){const s=d[0],i=d[1];let c=JSON.parse(JSON.stringify(e));for(let l=0;l<t;l++)if(l>>s&1){let b=l^1<<i;c[b]=e[l]}else c[l]=e[l];e=c}});let p=e.map(r=>`${r.re.toFixed(3)} + ${r.im.toFixed(3)}j`),m={};return e.forEach((r,a)=>{let d=r.re*r.re+r.im*r.im;d>.001&&(m[a.toString(2).padStart(o,"0")]=d)}),{statevector:p,probabilities:m,diagram:this.generateDiagram(n,o)}},generateDiagram(n,o){let t=`<svg viewBox="0 0 ${n.length*60+100} ${o*50+50}" xmlns="http://www.w3.org/2000/svg" style="background:transparent">`;for(let e=0;e<o;e++)t+=`<line x1="20" y1="${40+e*50}" x2="${n.length*60+80}" y2="${40+e*50}" stroke="var(--text-muted)" stroke-width="2" />`,t+=`<text x="5" y="${45+e*50}" fill="var(--text-muted)" font-size="12" font-family="monospace">q${e}</text>`;return n.forEach((e,p)=>{const m=(typeof e=="string"?e:e.name).toUpperCase(),r=typeof e=="string"?[0]:e.targets,a=50+p*60;if(m==="X"||m==="H"||m==="Z")r.forEach(d=>{const s=40+d*50;t+=`<rect x="${a-15}" y="${s-15}" width="30" height="30" rx="4" fill="var(--panel-bg)" stroke="var(--primary)" stroke-width="2" />`,t+=`<text x="${a}" y="${s+5}" fill="var(--primary)" font-size="14" font-weight="900" text-anchor="middle" font-family="sans-serif">${m}</text>`});else if(m==="CX"){const d=40+r[0]*50,s=40+r[1]*50;t+=`<circle cx="${a}" cy="${d}" r="4" fill="var(--primary)" />`,t+=`<line x1="${a}" y1="${d}" x2="${a}" y2="${s}" stroke="var(--primary)" stroke-width="2" />`,t+=`<circle cx="${a}" cy="${s}" r="10" fill="transparent" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${a-6}" y1="${s}" x2="${a+6}" y2="${s}" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${a}" y1="${s-6}" x2="${a}" y2="${s+6}" stroke="var(--primary)" stroke-width="2" />`}}),t+="</svg>",t}};function y(n){const o=f[n],t=document.getElementById("content-area");g=n;const e=document.getElementById("task-counter");if(e&&(n===0?e.style.display="none":(e.style.display="block",e.innerText=`Task ${n} / ${f.length-1}`)),o.content){t.innerHTML=o.content;return}t.innerHTML=`
        <h2 style="color:var(--text-muted); font-family:var(--font-heading); font-weight:400; font-size:1.1rem; margin-bottom:1rem; text-align:center">${o.title}</h2>
        <div class="sim-grid" style="display:grid; grid-template-columns:0.9fr 1fr 0.9fr; gap:24px; align-items:start;">

            <!-- COLUMN 1: Question -->
            <div class="question-box" style="display:flex; flex-direction:column; padding: 1.5rem; position: relative; min-height: 320px;">
                <button class="btn" onclick="viewAnswer()" style="position: absolute; top: 1rem; right: 1rem; background: transparent; border: none; color: var(--primary); cursor: pointer; font-size: 0.75rem; padding: 0; white-space: nowrap; display: flex; align-items: center; gap: 6px; font-weight: 600; z-index: 10;" title="View Answer">
                    <span>👁️</span> <span style="text-decoration: underline; text-underline-offset: 4px;">View Answer</span>
                </button>
                <div style="margin-bottom:1.25rem; padding-right: 100px;">
                    <div class="question-text" style="font-size: 1.05rem; line-height: 1.6; color:#fff">${o.question}</div>
                </div>
                <div style="margin-bottom:1.25rem">
                    <input type="text" id="user-input" placeholder="Type answer here..." autocomplete="off" style="padding: 12px 16px; font-size: 1rem;">
                </div>
                <div class="btn-container" style="margin-bottom:1.25rem; gap: 12px;">
                    <button class="btn btn-primary" style="padding: 10px 20px; font-size: 0.85rem;" onclick="checkAnswer()">CHECK ANSWER</button>
                    <button id="run-sim-btn" class="btn btn-secondary" style="padding: 10px 20px; font-size: 0.85rem;" disabled onclick="runSimulator()">RUN ▶</button>
                </div>
                <div style="margin-bottom:0.5rem;">
                    <button onclick="toggleReference()" style="background:var(--primary-glow); border:1px solid var(--primary); color:var(--primary); cursor:pointer; font-size:0.75rem; padding:6px 16px; border-radius:20px; transition:all 0.3s; font-weight:600">💡 SHOW HINT</button>
                    <div id="ref-content" style="display:none; margin-top:12px; background:rgba(255,255,255,0.04); border:1px solid var(--glass-border); padding:12px; border-radius:10px; font-size:0.95rem; color:var(--text-muted); line-height:1.6;">${o.reference}</div>
                </div>
                <div id="feedback-msg" class="feedback" style="margin-top:auto; padding: 10px 14px; font-size:1rem; border-radius:10px"></div>
            </div>

            <!-- COLUMN 2: Simulator Output -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.5rem; min-height: 320px;">
                <h3 style="margin:0 0 12px 0; color:var(--primary); font-size:0.95rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Simulator Visualization</h3>
                <div style="background:rgba(0,0,0,0.25); border-radius:12px; height:140px; display:flex; align-items:center; justify-content:center; overflow:hidden; margin-bottom:15px; border: 1px solid var(--glass-border);">
                    <div id="circuit-viz" style="width:100%; height:100%; display:flex; align-items:center; justify-content:center;"><span style="color:var(--text-muted); font-size:0.9rem">Run circuit to see diagram</span></div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom: 20px;">
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Statevector</div>
                        <div id="statevector-display" style="font-family:monospace; color:var(--accent); font-size:0.85rem; line-height:1.4">—</div>
                    </div>
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Probabilities</div>
                        <div style="margin-bottom:10px">
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>|0...0⟩</span><span id="prob-0">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-0" class="prob-fill"></div></div>
                        </div>
                        <div>
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>Others</span><span id="prob-1">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-1" class="prob-fill"></div></div>
                        </div>
                    </div>
                </div>
                <div style="margin-top:auto; display:flex; justify-content:space-between; gap:12px">
                    <button class="btn btn-outline" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px; border:1px solid var(--glass-border); color:var(--text-muted)" onclick="prevStep()">← PREVIOUS TASK</button>
                    <button class="btn btn-primary" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px" onclick="nextStep()">NEXT TASK →</button>
                </div>
            </div>

            <!-- COLUMN 3: Explanation & Logic -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.5rem; background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(255,255,255,0.08); min-height: 320px;">
                <h3 style="margin:0 0 15px 0; color:var(--secondary); font-size:0.95rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Explanation & Logic</h3>
                <div id="diagram-explain" style="font-size:0.9rem; color:#cbd5e1; line-height:1.6; padding:12px; background:rgba(255,255,255,0.03); border-radius:10px; margin-bottom:20px; border-left:4px solid var(--primary);">🔍 Run the simulator to see the explanation.</div>
                <div style="font-size: 0.7rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 10px; letter-spacing: 0.5px;">Quantum Logic</div>
                <div id="quantum-logic-ref" style="font-size:0.9rem; color:#fff; margin-bottom:15px; padding:0 5px;">
                    ${o.quantumLogic||"Algorithm Implementation"}
                </div>
                <div style="font-size: 0.7rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 10px; letter-spacing: 0.5px;">Package Reference</div>
                <div style="font-size:0.85rem; color:var(--text-muted); line-height:1.6; padding:12px; background:rgba(0,0,0,0.3); border-radius:10px; border: 1px solid rgba(255,255,255,0.05);">
                    <code id="package-ref-code" style="color:var(--accent); display:block; white-space: pre-wrap; font-family: monospace; font-size: 0.8rem;">${o.packageRef||"from qiskit import QuantumCircuit"}</code>
                </div>
            </div>
        </div>
    `}function w(){const n=document.getElementById("ref-content");n.style.display=n.style.display==="none"?"block":"none"}function k(){const n=f[g],o=document.getElementById("user-input");o.value=n.correctAnswer,x()}function x(){const n=f[g],o=document.getElementById("user-input").value.trim().toLowerCase(),t=document.getElementById("feedback-msg");n.answerValues.some(p=>o.includes(p.toLowerCase()))?(t.className="feedback correct",t.innerHTML=`<strong>Correct!</strong><br>${n.explanation}`,document.getElementById("run-sim-btn").disabled=!1):(t.className="feedback wrong",t.innerHTML="Try again!")}async function $(){const n=f[g],o=n.simulatorCode,t=n.num_qubits||1,e=n.num_bits||1,p=document.getElementById("statevector-display");p.innerHTML="Calculating...";const m=r=>{const a=document.getElementById("circuit-viz");if(r.diagram){a.innerHTML=r.diagram;const i=a.querySelector("svg");i&&(i.removeAttribute("width"),i.removeAttribute("height"),i.style.maxWidth="100%",i.style.maxHeight="100%",i.style.display="block")}document.getElementById("diagram-explain").innerHTML=n.diagramExplain,p.innerHTML=r.statevector.map((i,c)=>`|${c.toString(2).padStart(t,"0")}⟩: ${i}`).join("<br>");const d="0".repeat(t),s=r.probabilities[d]||0;h("prob-0","bar-0",s),h("prob-1","bar-1",1-s)};try{const r=await fetch("http://localhost:5000/api/week1/simulate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({gates:o,num_qubits:t,num_bits:e})});if(!r.ok)throw new Error("Backend offline");const a=await r.json();m(a)}catch(r){console.warn("Simulator Backend offline, switching to Local Mode.",r);const a=v.simulate(o,t);m(a),p.innerHTML+='<div style="margin-top:8px; font-size:0.65rem; color:var(--text-muted); border-top:1px solid rgba(255,255,255,0.05); padding-top:4px">⚠️ Local Mode (Backend unreachable)</div>'}}function h(n,o,t){const e=document.getElementById(n),p=document.getElementById(o);e&&(e.innerText=Math.round(t*100)+"%"),p&&(p.style.width=t*100+"%")}function q(){g<f.length-1&&(g++,y(g))}function S(){g>0&&(g--,y(g))}y(0);window.nextStep=q;window.prevStep=S;window.checkAnswer=x;window.viewAnswer=k;window.runSimulator=$;window.toggleReference=w;
