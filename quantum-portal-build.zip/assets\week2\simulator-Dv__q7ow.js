import"../modulepreload-polyfill-B5Qt9EMX.js";/* empty css               */const f=[{id:0,title:"Welcome to Week 2",content:`
            <div style="text-align:center; padding:2rem 0;">
                <p style="font-size:1.1rem; color:#cbd5e1">Mastering Qiskit Programming</p>
                <div style="text-align:left; display:inline-block; border-left:2px solid #38bdf8; padding-left:1rem; margin:2rem 0;">
                    <div style="font-weight:600; margin-bottom:0.8rem; color:#f8fafc">You will learn:</div>
                    <ul style="margin:0; padding-left:1rem; color:#cbd5e1; list-style-type:circle; line-height:1.8">
                        <li>Creating Quantum Circuits with Qiskit</li>
                        <li>Applying multiple gates in sequence</li>
                        <li>Entanglement (Bell States)</li>
                        <li>Complex statevectors</li>
                    </ul>
                </div>
                <div style="margin-top:2rem">
                    <button class="btn btn-primary" onclick="nextStep()" style="flex:0; width:180px; padding: 10px 16px; font-size: 0.85rem;">Start Week 2 →</button>
                    <div style="margin-top:1rem; font-size:0.9rem"><a href="../" style="color:#64748b">Exit to Dashboard</a></div>
                </div>
            </div>
        `},{id:1,title:"Task 1: The QuantumCircuit Object",reference:"<strong>Key Concept:</strong><br>In Qiskit, the primary object is <code>QuantumCircuit</code>. To create one with 1 qubit and 1 classical bit, we use <code>QuantumCircuit(1, 1)</code>.",question:"Which Qiskit class is used to define a quantum circuit?",answerValues:["QuantumCircuit","circuit","qc"],correctAnswer:"QuantumCircuit",explanation:"Correct! QuantumCircuit is the fundamental building block in Qiskit.",simulatorCode:["INIT"],diagramExplain:"📖 A blank circuit initialized. In code, this corresponds to <code>qc = QuantumCircuit(1, 1)</code>.",quantumLogic:"Circuit Object Initialization",packageRef:`from qiskit import QuantumCircuit
qc = QuantumCircuit(1, 1)`},{id:2,title:"Task 2: Applying Rotations",reference:"<strong>Key Concept:</strong><br>An X-gate corresponds to a 180-degree (π) rotation around the X-axis of the Bloch Sphere. It flips |0⟩ to |1⟩.",question:"If we apply an X gate to |0⟩, what is the resulting statevector for |1⟩?",answerValues:["1","1.0","one"],correctAnswer:"1",explanation:"Correct! The statevector becomes [0, 1], meaning 100% probability of |1⟩.",simulatorCode:["X"],diagramExplain:"📖 The X gate flips the statevector completely.",quantumLogic:"Bloch Sphere Rotation (π)",packageRef:`qc.x(0)
# Apply X rotation to qubit 0`},{id:3,title:"Task 3: Creating a Half-Flip",reference:"<strong>Key Concept:</strong><br>A Hadamard gate (H) rotates the state to a point exactly between |0⟩ and |1⟩. This is the 'equal superposition' state: $(|0\rangle + |1\rangle)/sqrt{2}$.",question:"What is the probability of measuring |0⟩ after applying an H gate?",answerValues:["50%","0.5","50","half"],correctAnswer:"50%",explanation:"Correct! The probability is $|1/sqrt{2}|^2 = 0.5$.",simulatorCode:["H"],diagramExplain:"📖 The H gate splits the probability bars equally (50/50).",quantumLogic:"Equatorial Superposition",packageRef:`qc.h(0)
# Create superposition state`},{id:4,title:"Task 4: Sequence of Gates",reference:"<strong>Key Concept:</strong><br>Gates can be chained. Applying H then X results in a superposition that is 'flipped' relative to the standard H state.",question:"Apply H then X. Is the state still in a 50/50 superposition?",answerValues:["yes","true","it is"],correctAnswer:"Yes",explanation:"Correct! Chaining gates doesn't necessarily break superposition, it just changes the 'phase' or components.",simulatorCode:["H","X"],diagramExplain:"📖 Notice two boxes on the line. The final probabilities remain 50/50.",quantumLogic:"Gate Sequencing & Composition",packageRef:`# Sequential operations
qc.h(0)
qc.x(0)`},{id:5,title:"Task 5: Intro to Entanglement (Bell State)",reference:"<strong>Key Concept:</strong><br>Entanglement requires 2 qubits. A 'Bell State' is created by applying H to the first qubit and then a Controlled-X (CX) from the first to the second. <code>qc.h(0); qc.cx(0, 1);</code>",question:"Which controlled gate is commonly used to create entanglement?",answerValues:["CX","CNOT","controlled-x"],correctAnswer:"CX",explanation:"Correct! The CX (or CNOT) gate is the key to entangling qubits.",simulatorCode:[{name:"H",targets:[0]},{name:"CX",targets:[0,1]}],num_qubits:2,num_bits:2,diagramExplain:"📖 This is a 2-qubit circuit! The line between q0 and q1 represents the CX gate. While our 1D probability chart here is simplified, in a real 2-qubit system, you'd see correlations between the two.",quantumLogic:"Multi-Qubit Entanglement",packageRef:`qc.h(0)
qc.cx(0, 1)
# Entangle Q0 and Q1`},{id:6,title:"Week 2 Completion",content:`
            <div style="text-align:center; padding:2rem 0;">
                <h2 style="color:#4ade80">🏆 Week 2 Mastered!</h2>
                <p style="color:#cbd5e1; margin-top:1rem">You've learned the basics of building circuits and manipulating states in Qiskit.</p>
                <div style="margin-top:2rem">
                    <a href="../" class="btn btn-primary" style="width:180px; padding: 10px 16px; font-size: 0.85rem;">Return to Home</a>
                </div>
            </div>
        `}];let u=0;const v={simulate(n,a=1){let t=Math.pow(2,a),e=new Array(t).fill(0).map(()=>({re:0,im:0}));e[0].re=1,n.forEach(r=>{const o=(typeof r=="string"?r:r.name).toUpperCase(),p=typeof r=="string"?[0]:r.targets;if(o==="X")p.forEach(s=>{let i=JSON.parse(JSON.stringify(e));for(let d=0;d<t;d++)if(d>>s&1){let l=d^1<<s;i[l]=e[d],i[d]=e[l]}e=i});else if(o==="H")p.forEach(s=>{const i=1/Math.sqrt(2);let d=new Array(t).fill(0).map(()=>({re:0,im:0}));for(let l=0;l<t;l++){let y=l>>s&1,g=l^1<<s;y===0&&(d[l].re+=e[l].re*i+e[g].re*i,d[l].im+=e[l].im*i+e[g].im*i,d[g].re+=e[l].re*i-e[g].re*i,d[g].im+=e[l].im*i-e[g].im*i)}e=d});else if(o==="Z")p.forEach(s=>{for(let i=0;i<t;i++)i>>s&1&&(e[i].re*=-1,e[i].im*=-1)});else if(o==="CX"){const s=p[0],i=p[1];let d=JSON.parse(JSON.stringify(e));for(let l=0;l<t;l++)if(l>>s&1){let y=l^1<<i;d[y]=e[l]}else d[l]=e[l];e=d}});let c=e.map(r=>`${r.re.toFixed(3)} + ${r.im.toFixed(3)}j`),m={};return e.forEach((r,o)=>{let p=r.re*r.re+r.im*r.im;p>.001&&(m[o.toString(2).padStart(a,"0")]=p)}),{statevector:c,probabilities:m,diagram:this.generateDiagram(n,a)}},generateDiagram(n,a){let t=`<svg viewBox="0 0 ${n.length*60+100} ${a*50+50}" xmlns="http://www.w3.org/2000/svg" style="background:transparent">`;for(let e=0;e<a;e++)t+=`<line x1="20" y1="${40+e*50}" x2="${n.length*60+80}" y2="${40+e*50}" stroke="var(--text-muted)" stroke-width="2" />`,t+=`<text x="5" y="${45+e*50}" fill="var(--text-muted)" font-size="12" font-family="monospace">q${e}</text>`;return n.forEach((e,c)=>{const m=(typeof e=="string"?e:e.name).toUpperCase(),r=typeof e=="string"?[0]:e.targets,o=50+c*60;if(m==="X"||m==="H"||m==="Z")r.forEach(p=>{const s=40+p*50;t+=`<rect x="${o-15}" y="${s-15}" width="30" height="30" rx="4" fill="var(--panel-bg)" stroke="var(--primary)" stroke-width="2" />`,t+=`<text x="${o}" y="${s+5}" fill="var(--primary)" font-size="14" font-weight="900" text-anchor="middle" font-family="sans-serif">${m}</text>`});else if(m==="CX"){const p=40+r[0]*50,s=40+r[1]*50;t+=`<circle cx="${o}" cy="${p}" r="4" fill="var(--primary)" />`,t+=`<line x1="${o}" y1="${p}" x2="${o}" y2="${s}" stroke="var(--primary)" stroke-width="2" />`,t+=`<circle cx="${o}" cy="${s}" r="10" fill="transparent" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${o-6}" y1="${s}" x2="${o+6}" y2="${s}" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${o}" y1="${s-6}" x2="${o}" y2="${s+6}" stroke="var(--primary)" stroke-width="2" />`}}),t+="</svg>",t}};function b(n){const a=f[n],t=document.getElementById("content-area");u=n;const e=document.getElementById("task-counter");if(e&&(n===0?e.style.display="none":(e.style.display="block",e.innerText=`Task ${n} / ${f.length-1}`)),a.content){t.innerHTML=a.content;return}t.innerHTML=`
        <h2 style="color:var(--text-muted); font-family:var(--font-heading); font-weight:400; font-size:1.1rem; margin-bottom:1rem; text-align:center">${a.title}</h2>
        <div class="sim-grid" style="display:grid; grid-template-columns:0.9fr 1fr 0.9fr; gap:24px; align-items:start;">

            <!-- COLUMN 1: Question -->
            <div class="question-box" style="display:flex; flex-direction:column; padding: 1.5rem; position: relative; min-height: 320px;">
                <button class="btn" onclick="viewAnswer()" style="position: absolute; top: 1rem; right: 1rem; background: transparent; border: none; color: var(--primary); cursor: pointer; font-size: 0.75rem; padding: 0; white-space: nowrap; display: flex; align-items: center; gap: 6px; font-weight: 600; z-index: 10;" title="View Answer">
                    <span>👁️</span> <span style="text-decoration: underline; text-underline-offset: 4px;">View Answer</span>
                </button>
                <div style="margin-bottom:1.25rem; padding-right: 100px;">
                    <div class="question-text" style="font-size: 1.05rem; line-height: 1.6; color:#fff">${a.question}</div>
                </div>
                <div style="margin-bottom:1.25rem">
                    <input type="text" id="user-input" placeholder="Type answer here..." autocomplete="off" style="padding: 12px 16px; font-size: 1rem;">
                </div>
                <div class="btn-container" style="margin-bottom:1.25rem; gap: 12px;">
                    <button class="btn btn-primary" style="padding: 10px 20px; font-size: 0.85rem;" onclick="checkAnswer()">CHECK ANSWER</button>
                    <button id="run-sim-btn" class="btn btn-secondary" style="padding: 10px 20px; font-size: 0.85rem;" disabled onclick="runSimulator()">RUN ▶</button>
                </div>
                <div style="margin-bottom:0.5rem;">
                    <button onclick="toggleReference()" style="background:var(--primary-glow); border:1px solid var(--primary); color:var(--primary); cursor:pointer; font-size:0.75rem; padding:6px 16px; border-radius:20px; transition:all 0.3s; font-weight:600">💡 SHOW HINT</button>
                    <div id="ref-content" style="display:none; margin-top:12px; background:rgba(255,255,255,0.04); border:1px solid var(--glass-border); padding:12px; border-radius:10px; font-size:0.95rem; color:var(--text-muted); line-height:1.6;">
                        ${a.reference}
                    </div>
                </div>
                <div id="feedback-msg" class="feedback" style="margin-top:auto; padding: 10px 14px; font-size:1rem; border-radius:10px"></div>
            </div>

            <!-- COLUMN 2: Simulator Output -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.5rem; min-height: 320px;">
                <h3 style="margin:0 0 12px 0; color:var(--primary); font-size:0.95rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Simulator Visualization</h3>
                <div style="background:rgba(0,0,0,0.25); border-radius:12px; height:140px; display:flex; align-items:center; justify-content:center; overflow:hidden; margin-bottom:15px; border: 1px solid var(--glass-border);">
                    <div id="circuit-viz" style="width:100%; height:100%; display:flex; align-items:center; justify-content:center;">
                        <span style="color:var(--text-muted); font-size:0.9rem">Run circuit to see diagram</span>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom: 20px;">
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Statevector</div>
                        <div id="statevector-display" style="font-family:monospace; color:var(--accent); font-size:0.85rem; line-height:1.4">—</div>
                    </div>
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Probabilities</div>
                        <div style="margin-bottom:10px">
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>|0...0⟩</span><span id="prob-0">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-0" class="prob-fill"></div></div>
                        </div>
                        <div>
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>Others</span><span id="prob-1">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-1" class="prob-fill"></div></div>
                        </div>
                    </div>
                </div>
                <div style="margin-top:auto; display:flex; justify-content:space-between; gap:12px">
                    <button class="btn btn-outline" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px; border:1px solid var(--glass-border); color:var(--text-muted)" onclick="prevStep()">← PREVIOUS TASK</button>
                    <button class="btn btn-primary" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px" onclick="nextStep()">NEXT TASK →</button>
                </div>
            </div>

            <!-- COLUMN 3: Explanation & Logic -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.5rem; background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(255,255,255,0.08); min-height: 320px;">
                <h3 style="margin:0 0 15px 0; color:var(--secondary); font-size:0.95rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Explanation & Logic</h3>
                <div id="diagram-explain" style="font-size:0.9rem; color:#cbd5e1; line-height:1.6; padding:12px; background:rgba(255,255,255,0.03); border-radius:10px; margin-bottom:20px; border-left:4px solid var(--primary);">
                    🔍 Run the simulator to see the explanation.
                </div>
                <div style="font-size: 0.7rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 10px; letter-spacing: 0.5px;">Quantum Logic</div>
                <div id="quantum-logic-ref" style="font-size:0.9rem; color:#fff; margin-bottom:15px; padding:0 5px;">
                    ${a.quantumLogic||"Qiskit Implementation"}
                </div>
                <div style="font-size: 0.7rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 10px; letter-spacing: 0.5px;">Package Reference</div>
                <div style="font-size:0.85rem; color:var(--text-muted); line-height:1.6; padding:12px; background:rgba(0,0,0,0.3); border-radius:10px; border: 1px solid rgba(255,255,255,0.05);">
                    <code id="package-ref-code" style="color:var(--accent); display:block; white-space: pre-wrap; font-family: monospace; font-size: 0.8rem;">${a.packageRef||"from qiskit import QuantumCircuit"}</code>
                </div>
            </div>
        </div>
    `}function w(){const n=document.getElementById("ref-content");n.style.display=n.style.display==="none"?"block":"none"}function k(){const n=f[u],a=document.getElementById("user-input");a.value=n.correctAnswer,h()}function h(){const n=f[u],a=document.getElementById("user-input").value.trim().toLowerCase(),t=document.getElementById("feedback-msg");if(n.answerValues.some(c=>a.includes(c.toLowerCase()))){t.className="feedback correct",t.innerHTML=`<strong>Correct!</strong><br>${n.explanation}`;const c=document.getElementById("run-sim-btn");c.disabled=!1,c.style.opacity="1"}else t.className="feedback wrong",t.innerHTML="Try again!"}async function C(){const n=f[u],a=n.simulatorCode,t=n.num_qubits||1,e=n.num_bits||1,c=document.getElementById("statevector-display");c&&(c.innerHTML="Calculating...");const m=r=>{const o=document.getElementById("circuit-viz");if(r.diagram&&o){o.innerHTML=r.diagram;const i=o.querySelector("svg");i&&(i.removeAttribute("width"),i.removeAttribute("height"),i.style.maxWidth="100%",i.style.maxHeight="100%",i.style.display="block")}document.getElementById("diagram-explain").innerHTML=n.diagramExplain,r.statevector&&c&&(c.innerHTML=r.statevector.map((i,d)=>`|${d.toString(2).padStart(t,"0")}⟩: ${i}`).join("<br>"));const p="0".repeat(t),s=r.probabilities[p]||0;x("prob-0","bar-0",s),x("prob-1","bar-1",1-s)};try{const r=await fetch("http://localhost:5000/api/week1/simulate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({gates:a,num_qubits:t,num_bits:e})});if(!r.ok)throw new Error("Backend offline");const o=await r.json();m(o)}catch(r){console.warn("Simulator Backend offline, switching to Local Mode.",r);const o=v.simulate(a,t);m(o),c&&(c.innerHTML+='<div style="margin-top:8px; font-size:0.65rem; color:var(--text-muted); border-top:1px solid rgba(255,255,255,0.05); padding-top:4px">⚠️ Local Mode (Backend unreachable)</div>')}}function x(n,a,t){const e=document.getElementById(n),c=document.getElementById(a);e&&(e.innerText=Math.round(t*100)+"%"),c&&(c.style.width=t*100+"%")}function q(){u<f.length-1&&(u++,b(u))}function S(){u>0&&(u--,b(u))}b(0);window.nextStep=q;window.prevStep=S;window.checkAnswer=h;window.viewAnswer=k;window.runSimulator=C;window.toggleReference=w;
