import"../modulepreload-polyfill-B5Qt9EMX.js";/* empty css               */const g=[{id:0,title:"Welcome",content:`
            <div style="text-align:center; padding:2rem 0;">
                <p style="font-size:1.1rem; color:var(--text-muted)">Welcome to Week 1 Quantum Simulator</p>
                <div style="text-align:left; display:inline-block; border-left:2px solid var(--primary); padding-left:1rem; margin:2rem 0;">
                    <div style="font-weight:600; margin-bottom:0.8rem; color:var(--text-main)">You will learn:</div>
                    <ul style="margin:0; padding-left:1rem; color:var(--text-muted); list-style-type:circle; line-height:1.8">
                        <li>What is a qubit (Initialization)</li>
                        <li>X gate (Bit Flip)</li>
                        <li>Hadamard gate (Superposition)</li>
                        <li>Measurement</li>
                    </ul>
                </div>
                <div style="margin-top:2rem">
                    <button class="btn btn-primary" onclick="nextStep()" style="flex:0; width:180px; padding: 10px 16px; font-size: 0.85rem;">Start Learning →</button>
                    <div style="margin-top:1rem; font-size:0.9rem"><a href="../" style="color:#64748b">Exit to Dashboard</a></div>
                </div>
            </div>
        `},{id:1,title:"Task No 1: Learn Qubit Initialization",reference:"<strong>Key Concept:</strong><br>In quantum computing (Qiskit), all qubits are initialized to the <b>Ground State |0⟩</b> by default. This is analogous to setting a bit to 0 at the start of a program.",question:"A qubit is initially in which state?<br><br>A) |0⟩ &nbsp; B) |1⟩ &nbsp; C) Both &nbsp; D) None",answerValues:["a","|0>","|0⟩","0"],correctAnswer:"|0⟩",explanation:"Correct Answer: A) |0⟩<br>By default, qubit starts in |0⟩ state.",simulatorCode:["INIT"],diagramExplain:"📖 <b>q</b> = Qubit (your quantum bit, like a coin). It starts in state |0⟩ (heads up).<br><b>c</b> = Classical bit (where the result is stored after measurement).<br>The <b>line</b> after q shows no gate is applied — just initialization.",quantumLogic:"Ground State Initialization",packageRef:`qc = QuantumCircuit(1)
# Initial state is |0⟩`},{id:2,title:"Task No 2: Learn X Gate (Bit Flip)",reference:"<strong>Key Concept:</strong><br>The <b>Pauli-X Gate</b> is the quantum NOT gate. It flips:<br>• |0⟩ → |1⟩<br>• |1⟩ → |0⟩",question:"Apply X gate to |0⟩. What is the output state?",answerValues:["|1>","|1⟩","1","one"],correctAnswer:"|1⟩",explanation:"Correct ✓<br>|0⟩ → |1⟩. X gate flips the qubit.",simulatorCode:["X"],diagramExplain:"📖 <b>q</b> = Qubit line. <b>c</b> = Classical bit line.<br>The <b style='color:var(--accent)'>X</b> box on the q line = <b>X Gate</b> (like flipping a coin from heads to tails).<br>It changes |0⟩ → |1⟩.",quantumLogic:"Pauli-X (NOT) Operation",packageRef:`qc.x(0)
# Flip qubit at index 0`},{id:3,title:"Task No 3: Hadamard Gate (Superposition)",reference:"<strong>Key Concept:</strong><br>The <b>Hadamard (H) Gate</b> creates <b>Superposition</b>. Applied to |0⟩, the qubit has equal (50%) probability of being 0 or 1.",question:"Apply Hadamard gate to |0⟩. What is probability of |1⟩?",answerValues:["50%","0.5","1/2","half","50"],correctAnswer:"50%",explanation:"Correct ✓<br>Probability of |1⟩ = 50%. Hadamard creates superposition.",simulatorCode:["H"],diagramExplain:"📖 <b>q</b> = Qubit line. <b>c</b> = Classical bit line.<br>The <b style='color:var(--accent)'>H</b> box on the q line = <b>Hadamard Gate</b>.<br>Think of it as spinning a coin in the air — it's both heads AND tails (50/50) until you look at it!",quantumLogic:"Hadamard (Superposition) Gate",packageRef:`qc.h(0)
# Put qubit 0 into superposition`},{id:4,title:"Task No 4: Measurement",reference:"<strong>Key Concept:</strong><br><b>Measurement</b> is destructive. It forces the qubit to 'collapse' from superposition into a definite state (|0⟩ or |1⟩).",question:"What happens after measurement of a superposition?",answerValues:["collapse","collapses","0 or 1","definite","outcome"],correctAnswer:"collapse",explanation:"Correct.<br>Measurement collapses the qubit to |0⟩ or |1⟩.",simulatorCode:["H","MEASURE"],diagramExplain:"📖 <b>q</b> = Qubit line. <b>c</b> = Classical bit line.<br>The <b style='color:var(--accent)'>H</b> box = Hadamard (creates superposition).<br>The <b style='color:var(--accent)'>meter icon ⊳</b> = <b>Measurement</b> — like catching the spinning coin. The arrow from q to c means the result is sent to the classical bit.<br>After measurement, the coin lands — either 0 or 1!",quantumLogic:"Observation & Collapse",packageRef:`qc.measure(0, 0)
# Measure qubit 0 to bit 0`},{id:5,title:"Task No 5: Double Bit Flip (Inverse)",reference:"<strong>Key Concept:</strong><br>Applying the X (NOT) gate twice returns the qubit to its original state. It is its own inverse!",question:"If you apply X gate twice to |0⟩, what is the final state?",answerValues:["|0>","|0⟩","0","zero"],correctAnswer:"|0⟩",explanation:"Correct ✓<br>X then X = No change. |0⟩ → |1⟩ → |0⟩.",simulatorCode:["X","X"],diagramExplain:"📖 Two <b style='color:var(--accent)'>X</b> boxes. First flip makes it |1⟩, second flip brings it back to |0⟩.",quantumLogic:"Self-Inverting Gates (X² = I)",packageRef:`qc.x(0)
qc.x(0)
# Double flip`},{id:6,title:"Task No 6: Superposition from |1⟩",reference:"<strong>Key Concept:</strong><br>The H gate creates superposition regardless of the starting state. |1⟩ also becomes a 50/50 mix.",question:"Apply X then H. What is the probability of the |1⟩ state?",answerValues:["50%","0.5","50"],correctAnswer:"50%",explanation:"Correct ✓<br>H gate always creates a 50/50 split on a single qubit.",simulatorCode:["X","H"],diagramExplain:"📖 <b style='color:var(--accent)'>X</b> flips it to |1⟩, then <b style='color:var(--accent)'>H</b> puts it in superposition.",quantumLogic:"State Transformation",packageRef:`qc.x(0)
qc.h(0)
# |0⟩ -> |1⟩ -> |+⟩`},{id:7,title:"Task No 7: Hadamard is its own Inverse",reference:"<strong>Key Concept:</strong><br>Like the X gate, applying H twice returns the state to normal. H(H|0⟩) = |0⟩.",question:"Apply H twice to |0⟩. What is the final state?",answerValues:["|0>","|0⟩","0"],correctAnswer:"|0⟩",explanation:"Correct ✓<br>H then H cancels out. Quantum gates are often reversible!",simulatorCode:["H","H"],diagramExplain:"📖 Two <b style='color:var(--accent)'>H</b> boxes. The first creates superposition, the second reverses it back to |0⟩.",quantumLogic:"Quantum Reversibility (H² = I)",packageRef:`qc.h(0)
qc.h(0)
# Superposition and Back`},{id:8,title:"Task No 8: Measuring after Bit Flip",reference:"<strong>Key Concept:</strong><br>If you measure a qubit that is definitely in state |1⟩, you will get '1' every time.",question:"Apply X then Measure. What outcome will you see in 'c' (Classical bit)?",answerValues:["1","|1>","|1⟩"],correctAnswer:"1",explanation:"Correct ✓<br>X flips it to |1⟩, and measurement confirms it.",simulatorCode:["X","MEASURE"],diagramExplain:"📖 <b style='color:var(--accent)'>X</b> flips the qubit, and the <b>meter</b> reads the final state."},{id:9,title:"Task No 9: The Identity Gate (I)",reference:"<strong>Key Concept:</strong><br>The <b>Identity (I) Gate</b> is a gate that does nothing. It is used in quantum circuits as a placeholder or time-delay.",question:"Which gate acts as a 'no-operation' and keeps the state same?",answerValues:["identity","i","i gate"],correctAnswer:"Identity",explanation:"Correct ✓<br>The I gate is the mathematical identity: I|ψ⟩ = |ψ⟩.",simulatorCode:["I"],diagramExplain:"📖 The qubit state remains unchanged."},{id:10,title:"Task No 10: Phase Flip (Z Gate)",reference:"<strong>Key Concept:</strong><br>The <b>Pauli-Z Gate</b> flips the phase of the |1⟩ component. It does not change the probability of |0⟩ if applied to |0⟩.",question:"Apply Z to |0⟩. Does the probability of |0⟩ change from 100%?",answerValues:["no","never","0","false"],correctAnswer:"No",explanation:"Correct ✓<br>Z|0⟩ = |0⟩. It only affects the 'phase' of the |1⟩ state.",simulatorCode:["Z"],diagramExplain:"📖 The <b style='color:var(--accent)'>Z</b> box flips the phase. Since we are in |0⟩, nothing visible changes in the probabilities."},{id:11,title:"Task No 11: Final Practice",content:`
            <h2 style="font-size:1.1rem; color:var(--text-main); text-align:center; margin-bottom:0.8rem">🎉 Task No 11: Final Practice Circuit</h2>
            
            <div style="display:grid; grid-template-columns:1fr 1.2fr; gap:16px; align-items:start;">
                
                <!-- LEFT: Steps + Run -->
                <div class="question-box">
                    <div style="font-size:0.9rem; margin-bottom:0.8rem; color:var(--text-muted); line-height:1.8">
                        <div>✅ Step 1: Initialize |0⟩</div>
                        <div>✅ Step 2: Apply Hadamard</div>
                        <div>✅ Step 3: Measure</div>
                    </div>
                    <button class="btn btn-primary" onclick="runSimulator(['H','MEASURE'])" style="width:100%">Run Circuit ▶</button>
                    
                    <div style="margin-top:1rem; padding-top:0.8rem; border-top:1px solid var(--glass-border); text-align:center">
                        <p style="color:#4ade80; font-size:0.85rem; margin:0 0 8px 0">🏆 You completed Week 1 Simulator!</p>
                        <a href="../" class="btn btn-secondary" style="text-decoration:none; display:inline-block; width:140px; text-align:center; padding:8px">Finish & Exit</a>
                    </div>
                </div>

                <!-- RIGHT: Output -->
                <div class="result-box" style="display:block;">
                    <h3 style="margin:0 0 8px 0; color:var(--primary); font-size:0.9rem">Simulation Output</h3>
                    <div style="background:var(--card-hover); border-radius:6px; height:120px; display:flex; align-items:center; justify-content:center; overflow:hidden; margin-bottom:10px">
                        <div id="circuit-viz" style="width:100%; height:100%; display:flex; align-items:center; justify-content:center;">
                            <span style="color:#64748b; font-size:0.8rem">Run circuit to see diagram</span>
                        </div>
                    </div>
                    <div id="diagram-explain" style="font-size:0.75rem; color:var(--text-muted); line-height:1.4; padding:5px 8px; background:var(--card-hover); border-radius:4px; margin-bottom:8px; border-left:2px solid var(--primary);">
                        📖 Run the circuit to see the diagram explained.
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px">
                        <div class="sim-block" style="padding:8px">
                            <div class="sim-label">State |0⟩</div>
                            <div style="font-size:1.1rem; font-weight:bold" id="prob-0">0%</div>
                            <div class="prob-bar"><div id="bar-0" class="prob-fill"></div></div>
                        </div>
                        <div class="sim-block" style="padding:8px">
                            <div class="sim-label">State |1⟩</div>
                            <div style="font-size:1.1rem; font-weight:bold" id="prob-1">0%</div>
                            <div class="prob-bar"><div id="bar-1" class="prob-fill"></div></div>
                        </div>
                    </div>
                </div>
            </div>
        `}];let b=0;const x={simulate(n,a=1){let t=Math.pow(2,a),e=new Array(t).fill(0).map(()=>({re:0,im:0}));e[0].re=1,n.forEach(d=>{const r=(typeof d=="string"?d:d.name).toUpperCase(),l=typeof d=="string"?[0]:d.targets;if(r==="X")l.forEach(o=>{let s=JSON.parse(JSON.stringify(e));for(let c=0;c<t;c++)if(c>>o&1){let i=c^1<<o;s[i]=e[c],s[c]=e[i]}e=s});else if(r==="H")l.forEach(o=>{const s=1/Math.sqrt(2);let c=new Array(t).fill(0).map(()=>({re:0,im:0}));for(let i=0;i<t;i++){let f=i>>o&1,u=i^1<<o;f===0&&(c[i].re+=e[i].re*s+e[u].re*s,c[i].im+=e[i].im*s+e[u].im*s,c[u].re+=e[i].re*s-e[u].re*s,c[u].im+=e[i].im*s-e[u].im*s)}e=c});else if(r==="Z")l.forEach(o=>{for(let s=0;s<t;s++)s>>o&1&&(e[s].re*=-1,e[s].im*=-1)});else if(r==="CX"){const o=l[0],s=l[1];let c=JSON.parse(JSON.stringify(e));for(let i=0;i<t;i++)if(i>>o&1){let f=i^1<<s;c[f]=e[i]}else c[i]=e[i];e=c}});let m=e.map(d=>`${d.re.toFixed(3)} + ${d.im.toFixed(3)}j`),p={};return e.forEach((d,r)=>{let l=d.re*d.re+d.im*d.im;l>.001&&(p[r.toString(2).padStart(a,"0")]=l)}),{statevector:m,probabilities:p,diagram:this.generateDiagram(n,a)}},generateDiagram(n,a){let t=`<svg viewBox="0 0 ${n.length*60+100} ${a*50+50}" xmlns="http://www.w3.org/2000/svg" style="background:transparent">`;for(let e=0;e<a;e++)t+=`<line x1="20" y1="${40+e*50}" x2="${n.length*60+80}" y2="${40+e*50}" stroke="var(--text-muted)" stroke-width="2" />`,t+=`<text x="5" y="${45+e*50}" fill="var(--text-muted)" font-size="12" font-family="monospace">q${e}</text>`;return n.forEach((e,m)=>{const p=(typeof e=="string"?e:e.name).toUpperCase(),d=typeof e=="string"?[0]:e.targets,r=50+m*60;if(p==="X"||p==="H"||p==="Z")d.forEach(l=>{const o=40+l*50;t+=`<rect x="${r-15}" y="${o-15}" width="30" height="30" rx="4" fill="var(--panel-bg)" stroke="var(--primary)" stroke-width="2" />`,t+=`<text x="${r}" y="${o+5}" fill="var(--primary)" font-size="14" font-weight="900" text-anchor="middle" font-family="sans-serif">${p}</text>`});else if(p==="CX"){const l=40+d[0]*50,o=40+d[1]*50;t+=`<circle cx="${r}" cy="${l}" r="4" fill="var(--primary)" />`,t+=`<line x1="${r}" y1="${l}" x2="${r}" y2="${o}" stroke="var(--primary)" stroke-width="2" />`,t+=`<circle cx="${r}" cy="${o}" r="10" fill="transparent" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${r-6}" y1="${o}" x2="${r+6}" y2="${o}" stroke="var(--primary)" stroke-width="2" />`,t+=`<line x1="${r}" y1="${o-6}" x2="${r}" y2="${o+6}" stroke="var(--primary)" stroke-width="2" />`}}),t+="</svg>",t}};function y(n){const a=g[n],t=document.getElementById("content-area");b=n;const e=document.getElementById("task-counter");if(e&&(n===0?e.style.display="none":(e.style.display="block",e.innerText=`Task ${n} / ${g.length-1}`)),a.content){t.innerHTML=a.content;return}t.innerHTML=`
        <h2 style="color:var(--text-muted); font-family:var(--font-heading); font-weight:400; font-size:1.1rem; margin-bottom:1rem; text-align:center">${a.title}</h2>
        <div class="sim-grid" style="display:grid; grid-template-columns:0.9fr 1fr 0.9fr; gap:24px; align-items:start;">

            <!-- COLUMN 1: Question -->
            <div class="question-box" style="display:flex; flex-direction:column; padding: 1.5rem; position: relative; min-height: 320px;">
                <button class="btn" onclick="viewAnswer()" style="position: absolute; top: 1rem; right: 1rem; background: transparent; border: none; color: var(--primary); cursor: pointer; font-size: 0.75rem; padding: 0; white-space: nowrap; display: flex; align-items: center; gap: 6px; font-weight: 600; z-index: 10;" title="View Answer">
                    <span>👁️</span> <span style="text-decoration: underline; text-underline-offset: 4px;">View Answer</span>
                </button>
                <div style="margin-bottom:1.25rem; padding-right: 100px;">
                    <div class="question-text" style="font-size: 1.05rem; line-height: 1.6; color:var(--text-main)">${a.question}</div>
                </div>
                <div style="margin-bottom:1.25rem">
                    <input type="text" id="user-input" placeholder="Type answer here..." autocomplete="off" style="padding: 12px 16px; font-size: 1rem;">
                </div>
                <div class="btn-container" style="margin-bottom:1.25rem; gap: 12px;">
                    <button class="btn btn-primary" style="padding: 10px 20px; font-size: 0.85rem;" onclick="checkAnswer()">CHECK ANSWER</button>
                    <button id="run-sim-btn" class="btn btn-secondary" style="padding: 10px 20px; font-size: 0.85rem;" disabled onclick="runSimulator()">RUN ▶</button>
                </div>
                <div style="margin-bottom:0.5rem;">
                    <button onclick="toggleReference()" style="background:var(--primary-glow); border:1px solid var(--primary); color:var(--primary); cursor:pointer; font-size:0.75rem; padding:6px 16px; border-radius:20px; transition:all 0.3s; font-weight:600">💡 SHOW HINT</button>
                    <div id="ref-content" style="display:none; margin-top:12px; background:var(--panel-bg); border:1px solid var(--glass-border); padding:12px; border-radius:10px; font-size:0.95rem; color:var(--text-muted); line-height:1.6;">
                        ${a.reference}
                    </div>
                </div>
                <div id="feedback-msg" class="feedback" style="margin-top:auto; padding: 10px 14px; font-size:1rem; border-radius:10px"></div>
            </div>

            <!-- COLUMN 2: Simulator Output -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.5rem; min-height: 320px;">
                <h3 style="margin:0 0 12px 0; color:var(--primary); font-size:0.95rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Simulator Visualization</h3>
                <div style="background:rgba(0,0,0,0.25); border-radius:12px; height:140px; display:flex; align-items:center; justify-content:center; overflow:hidden; margin-bottom:15px; border: 1px solid var(--glass-border);">
                    <div id="circuit-viz" style="width:100%; height:100%; display:flex; align-items:center; justify-content:center;">
                        <span style="color:var(--text-muted); font-size:0.9rem">Run circuit to see diagram</span>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom: 20px;">
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Statevector</div>
                        <div id="statevector-display" style="font-family:monospace; color:var(--accent); font-size:0.85rem; line-height:1.4">—</div>
                    </div>
                    <div class="sim-block" style="padding: 12px; background: rgba(255,255,255,0.02); border-radius:12px">
                        <div class="sim-label" style="font-size: 0.75rem; margin-bottom: 6px;">Probabilities</div>
                        <div style="margin-bottom:10px">
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>|0⟩</span><span id="prob-0">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-0" class="prob-fill"></div></div>
                        </div>
                        <div>
                            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px"><span>|1⟩</span><span id="prob-1">0%</span></div>
                            <div class="prob-bar" style="height: 8px;"><div id="bar-1" class="prob-fill"></div></div>
                        </div>
                    </div>
                </div>
                <div style="margin-top:auto; display:flex; justify-content:space-between; gap:12px">
                    <button class="btn btn-outline" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px; border:1px solid var(--glass-border); color:var(--text-muted)" onclick="prevStep()">← PREVIOUS TASK</button>
                    <button class="btn btn-primary" style="padding: 12px 24px; font-size: 0.9rem; flex:1; border-radius:12px" onclick="nextStep()">NEXT TASK →</button>
                </div>
            </div>

            <!-- COLUMN 3: Explanation & Logic -->
            <div class="result-box" style="display:flex; flex-direction:column; padding: 1.75rem; background: var(--panel-bg); border: 1px solid var(--glass-border); border-radius: 20px; min-height: 320px;">
                <h3 style="margin:0 0 20px 0; color:var(--secondary); font-size:1rem; font-family:var(--font-heading); text-transform:uppercase; letter-spacing:1px">Explanation & Logic</h3>
                <div id="diagram-explain" style="font-size:1rem; color:var(--text-muted); line-height:1.7; padding:15px; background:var(--card-hover); border-radius:12px; margin-bottom:25px; border-left:5px solid var(--primary);">
                    🔍 Run the simulator to see the explanation.
                </div>
                <div style="font-size: 0.75rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 12px; letter-spacing: 0.5px;">Quantum Logic</div>
                <div id="quantum-logic-ref" style="font-size:0.9rem; color:var(--text-main); margin-bottom:15px; padding:0 5px;">
                    ${a.quantumLogic||"Qiskit Implementation"}
                </div>
                <div style="font-size: 0.75rem; color: var(--primary); text-transform: uppercase; font-weight: 700; margin-bottom: 12px; letter-spacing: 0.5px;">Package Reference</div>
                <div style="font-size:0.85rem; color:var(--text-muted); line-height:1.7; padding:12px; background:var(--card-hover); border-radius:12px; border: 1px solid var(--glass-border-bright);">
                    <code id="package-ref-code" style="color:var(--accent); display:block; white-space: pre-wrap; font-family: monospace; font-size: 0.85rem;">${a.packageRef||"from qiskit import QuantumCircuit"}</code>
                </div>
            </div>
    </div>
    `}function w(){const n=document.getElementById("ref-content");n.style.display=n.style.display==="none"?"block":"none"}function k(){const n=g[b],a=document.getElementById("user-input");a.value=n.correctAnswer,v()}function v(){const n=g[b],a=document.getElementById("user-input").value.trim().toLowerCase(),t=document.getElementById("feedback-msg");if(n.answerValues.some(m=>a.includes(m.toLowerCase()))){t.className="feedback correct",t.innerHTML=`<strong>Correct!</strong><br>${n.explanation}`;const m=document.getElementById("run-sim-btn");m.disabled=!1,m.style.opacity="1",m.innerHTML="Run Simulator ▶"}else t.className="feedback wrong",t.innerHTML="Try again! Click <b>? Hint</b> for reference."}async function q(n=null){const a=g[b],t=n||a.simulatorCode,e=a.num_qubits||1,m=a.num_bits||1,p=document.getElementById("statevector-display");p&&(p.innerHTML="Calculating...");const d=r=>{const l=document.getElementById("circuit-viz");if(r.diagram&&l){l.innerHTML=r.diagram;const i=l.querySelector("svg");i&&(i.removeAttribute("width"),i.removeAttribute("height"),i.style.maxWidth="100%",i.style.maxHeight="100%",i.style.width="auto",i.style.height="auto",i.style.display="block")}const o=document.getElementById("diagram-explain");o&&a.diagramExplain&&(o.innerHTML=a.diagramExplain),r.statevector&&p&&(p.innerHTML=r.statevector.map((i,f)=>`|${f.toString(2).padStart(e,"0")}⟩: ${i}`).join("<br>"));const s="0".repeat(e),c=r.probabilities[s]||0;h("prob-0","bar-0",c),h("prob-1","bar-1",1-c)};try{const r=await fetch("http://localhost:5000/api/week1/simulate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({gates:t,num_qubits:e,num_bits:m})});if(!r.ok)throw new Error("Backend offline");const l=await r.json();d(l)}catch(r){console.warn("Simulator Backend offline, switching to Local Mode.",r);const l=x.simulate(t,e);d(l),p&&(p.innerHTML+='<div style="margin-top:8px; font-size:0.65rem; color:var(--text-muted); border-top:1px solid rgba(255,255,255,0.05); padding-top:4px">⚠️ Local Mode (Backend unreachable)</div>')}}function h(n,a,t){const e=document.getElementById(n),m=document.getElementById(a);e&&(e.innerText=Math.round(t*100)+"%"),m&&(m.style.width=t*100+"%")}function S(){b<g.length-1&&(b++,y(b))}function T(){b>0&&(b--,y(b))}y(0);window.nextStep=S;window.prevStep=T;window.checkAnswer=v;window.viewAnswer=k;window.runSimulator=q;window.toggleReference=w;
